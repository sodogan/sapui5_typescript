import UIComponent from "sap/ui/core/UIComponent";
import { support } from "sap/ui/Device";
import Models from "./model/Models";
import Model from "sap/ui/model/Model";



/**
 * @namespace ui5.typescript.helloworld
 */
export default class Component extends UIComponent {

	public static metadata = {
		manifest: "json"
	};

	private  _modelHelper:Models = new Models();

	private contentDensityClass: string;

	public init(): void {
		// call the base component's init function
		super.init();
		if(this._modelHelper ===undefined){
         this._modelHelper = new Models();
		}
		//here set the Model
		const deviceModel = this._modelHelper.createDeviceModel() as Model;
        super.setModel(deviceModel,"device");

	}

	/**
	 * This method can be called to determine whether the sapUiSizeCompact or sapUiSizeCozy
	 * design mode class should be set, which influences the size appearance of some controls.
	 *
	 * @public
	 * @return {string} css class, either 'sapUiSizeCompact' or 'sapUiSizeCozy' - or an empty string if no css class should be set
	 */
	public getContentDensityClass(): string {
		if (this.contentDensityClass === undefined) {
			// check whether FLP has already set the content density class; do nothing in this case
			if (document.body.classList.contains("sapUiSizeCozy") || document.body.classList.contains("sapUiSizeCompact")) {
				this.contentDensityClass = "";
			} else if (!support.touch) { // apply "compact" mode if touch is not supported
				this.contentDensityClass = "sapUiSizeCompact";
			} else {
				// "cozy" in case of touch support; default for most sap.m controls, but needed for desktop-first controls like sap.ui.table.Table
				this.contentDensityClass = "sapUiSizeCozy";
			}
		}
		return this.contentDensityClass;
	}

}
